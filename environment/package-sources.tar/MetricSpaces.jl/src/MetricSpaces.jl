module MetricSpaces

using Distances
using Base.Threads
using StatsBase: mean, median
using ProgressMeter
using StaticArrays
import Random
using Graphs: Graph, add_edge!

export 
    mean;

include("base/types.jl");
export 
    MetricSpace,
    EuclideanSpace,
    as_matrix,
    SubsetIndex,
    CoveringIndices;

include("base/real.jl");
export Interval,
    IntervalCovering,
    is_not_disjoint,
    in;

include("base/norm.jl");
export 
    norm, 
    normalize, 
    normalize!;

include("base/distances.jl");
export 
    pairwise_distance,
    pairwise_distance_summary;

include("base/ball.jl");
export 
    ball, 
    ball_ids;

include("base/distance functions.jl");
export
    dist_euclidean,
    dist_cityblock,
    dist_chebyshev,
    dist_cosine,
    dist_hamming,
    dist_correlation,
    dist_minkowski;

include("extra/neighborhood.jl");
export 
    k_neighbors;

include("extra/filters.jl");
export
    distance_to_measure,
    eccentricity,
    knn_density,
    dtm_density,
    kde;

include("extra/datasets/datasets.jl");

include("extra/sampling.jl");
export
    epsilon_net,
    farthest_points_sample_ids,
    farthest_points_sample,
    random_sample;

include("extra/nerve.jl");
export
    nerve_1d,
    nerve_2d,
    min_intersection,
    percentage_intersection,
    jaccard_threshold;

include("extra/transformations.jl");
export
    include_space,
    translate_space,
    center,
    scale,
    standardize,
    embed;

include("extra/geodesic.jl");
export geodesic_distance;

include("extra/images.jl")
export ImageFiltration, height_filtration, radial_filtration, dilation_filtration,
    erosion_filtration, signed_distance_filtration, euclidean_distance_transform,
    image_filtration_model

include("extra/euler.jl")
export EulerCurve, EulerTransform, SmoothEulerTransform, cubical_ecc,
    sample_directions, ect, sect, euler_table

end
